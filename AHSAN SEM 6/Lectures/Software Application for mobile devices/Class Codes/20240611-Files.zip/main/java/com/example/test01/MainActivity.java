package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onBtnClicked(View view) {
        //By default we will be on root folder that is read-only for apps.
        //We have to get app specific folder by getFilesDir() for filing purpose.

        File file=getFilesDir();//working directory
        Log.d("abcd", file.toString());
        try {
            FileOutputStream fos=new FileOutputStream(file.toString()+"/data.txt");
            fos.close();
        } catch (Exception e) {
            Log.e("abcd", e.getMessage());
        }
    }
}