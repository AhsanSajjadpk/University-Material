package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//With synchronization block
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onBtnStart(View view) {
        int[] iArray = {11, 22, 33, 44, 55};//Reference type

        DisplayThread th1 = new DisplayThread(iArray);
        DisplayThread th2 = new DisplayThread(iArray);
        th1.start();
        th2.start();
    }
}