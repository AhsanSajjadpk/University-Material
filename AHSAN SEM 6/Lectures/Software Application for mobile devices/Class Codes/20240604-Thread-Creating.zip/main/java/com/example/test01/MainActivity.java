package com.example.test01;
//Creating threads by extending Thread and implenenting Runnable
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
//This program displays information about current thread
public class MainActivity extends AppCompatActivity {
    public static final String TAG="abcd";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Thread th = Thread.currentThread();
        Log.d(MainActivity.TAG, "Thread ID: " + th.getId());
    }


    public void onBtnCreateThread1(View view) {
        MyThread01 thread01=new MyThread01();

        thread01.start();//Parallel execution, asynchronous way
        //thread01.run();//synchronous call, not parallel execution
    }

    public void onBtnCreateThread2(View view) {
        Thread th=new Thread(new MyThread02());

        th.start();

        /*
        //Anonymous object of an anonymous class
        new Thread(new Runnable() {
            @Override
            public void run() {

            }
        }).start();
        */

    }
}