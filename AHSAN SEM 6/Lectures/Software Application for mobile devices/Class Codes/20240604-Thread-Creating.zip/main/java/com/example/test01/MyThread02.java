package com.example.test01;

import android.util.Log;
//Thread is created by implementing Runnable interface
public class MyThread02 implements Runnable{
    @Override
    public void run() {
        try {
            Thread th = Thread.currentThread();
            Log.d(MainActivity.TAG, "Thread ID: " + th.getId());
            for (int ch = 1; ch <= 10; ch++) {
                Log.d(MainActivity.TAG, "MyThread02: " + ch);
                Thread.sleep(500);//raise an exception
            }
        }catch (Exception ex){
            Log.e(MainActivity.TAG, ex.getMessage());
        }
    }
}
