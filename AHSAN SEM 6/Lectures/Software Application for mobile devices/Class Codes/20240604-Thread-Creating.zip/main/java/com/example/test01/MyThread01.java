package com.example.test01;

import android.util.Log;
//Thread is created by extending Thread class
public class MyThread01 extends Thread{
    @Override
    public void run() {
        super.run();
        try {
            Thread th = Thread.currentThread();
            Log.d(MainActivity.TAG, "Thread ID: " + th.getId());
            for (int ch = 'A'; ch <= 'J'; ch++) {
                Log.d(MainActivity.TAG, "MyThread01: " + (char) ch);
                Thread.sleep(500);//raise an exception
            }
        }catch (Exception ex){
            Log.e(MainActivity.TAG, ex.getMessage());
        }
    }
}
