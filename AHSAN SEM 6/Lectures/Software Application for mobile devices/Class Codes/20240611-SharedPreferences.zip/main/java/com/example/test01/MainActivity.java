package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {

    SharedPreferences sp;
    EditText edtData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp=getPreferences(Context.MODE_PRIVATE);
        edtData=findViewById(R.id.edtData);

        onBtnGetClicked(null);
    }

    public void onBtnPutClicked(View view) {
        String sData=edtData.getText().toString();

        SharedPreferences.Editor editor=sp.edit();
        editor.putString("data", sData);
        editor.commit();

        edtData.setText("");
    }

    public void onBtnGetClicked(View view) {
        String sData=sp.getString("data", "Data not found!");

        edtData.setText(sData);
    }
}