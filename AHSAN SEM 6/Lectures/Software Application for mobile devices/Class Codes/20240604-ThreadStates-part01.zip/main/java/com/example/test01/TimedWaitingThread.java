package com.example.test01;

import android.util.Log;

public class TimedWaitingThread extends Thread{
    @Override
    public void run() {
        super.run();
        try{
            Log.d(MainActivity.TAG, "TimedWaitingThread is going to sleep");
            Thread.sleep(1000);
            Log.d(MainActivity.TAG, "TimedWaitingThread is awaken");
        }catch(Exception ex){
            Log.e(MainActivity.TAG, ex.getMessage());
        }
    }
}
