package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public static final String TAG="abcd";
    SampleThread sampleThread;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sampleThread=new SampleThread();
    }

    public void onBtnThreadInfo1(View view) {
        try {
            Log.d(TAG, "SampleThread State: " + sampleThread.getState());//NEW
            sampleThread.start();
            Thread.sleep(1);
            Log.d(TAG, "SampleThread State: " + sampleThread.getState());//RUNNABLE
        }catch(Exception ex){
            Log.e(TAG, ex.getMessage());
        }
    }

    public void onBtnThreadInfo2(View view) {
        //Press this button after pressing Info1 button, after some seconds
        Log.d(TAG, "SampleThread State: " + sampleThread.getState());//TERMINATED


        //going for TIMED_WAITING
        try {
            TimedWaitingThread th=new TimedWaitingThread();
            th.start();
            Thread.sleep(10);
            Log.d(TAG, "TimedWaitingThread State: " + th.getState());//TERMINATED

        }catch(Exception ex){
            Log.e(TAG, ex.getMessage());
        }



    }
}