package com.example.test01;

import android.util.Log;

public class SampleThread extends Thread{
    @Override
    public void run() {
        super.run();
        for(int k=1;k<=10000;k++);//busy waiting. will utilize cpu
    }
}
