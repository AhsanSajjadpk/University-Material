package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
//This program displays information about current thread
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onBtnInfo(View view) {
        Thread th=Thread.currentThread();//Get the current thread object
        Log.d("abcd", "ID       = " + th.getId());
        Log.d("abcd", "Name     = " + th.getName());
        Log.d("abcd", "Priority = " + th.getPriority());
        Log.d("abcd", "State    = " + th.getState());
        Log.d("abcd", "MAX_PRIORITY    = " + Thread.MAX_PRIORITY);
        Log.d("abcd", "MIN_PRIORITY    = " + Thread.MIN_PRIORITY);
    }
}