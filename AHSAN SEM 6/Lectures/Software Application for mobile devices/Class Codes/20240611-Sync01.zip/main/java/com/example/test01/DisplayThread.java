package com.example.test01;

//This thread will print provided int array on screen

import android.util.Log;

public class DisplayThread extends Thread {

    private int[] iNums;

    public DisplayThread(int[] iNums) {
        this.iNums = iNums;
    }

    @Override
    public void run() {
        try {
            Log.d("abcd", "Array={");
            for (int k = 0; k < iNums.length; k++) {
                Log.d("abcd", iNums[k] + " ");
                Thread.sleep(500);
            }
            Log.d("abcd", "}");
        } catch (Exception ex) {
            Log.e("abcd", ex.getMessage());
        }
    }
}
