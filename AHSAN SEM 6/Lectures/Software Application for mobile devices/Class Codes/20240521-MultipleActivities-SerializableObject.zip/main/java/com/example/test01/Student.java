package com.example.test01;

import java.io.Serializable;

public class Student implements Serializable {
    String name;
    Integer reg;
    Float cgpa;

    Student(){
        name="";
        reg=0;
        cgpa=0.0f;
    }
}
