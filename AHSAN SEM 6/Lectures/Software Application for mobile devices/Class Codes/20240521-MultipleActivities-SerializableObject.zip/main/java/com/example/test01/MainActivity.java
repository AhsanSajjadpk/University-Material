package com.example.test01;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    static public final String STD_OBJ="1";
    static public final String INPUT_FIELD="2";

    final int REQUEST_INPUT_ACTIVITY=100;

    Intent inputActivityIntent;
    Student std;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputActivityIntent=new Intent(getApplicationContext(), InputActivity.class);
        std=new Student();
    }

    public void onTextClicked(View view) {

        inputActivityIntent.putExtra(STD_OBJ, std);
        inputActivityIntent.putExtra(INPUT_FIELD,view.getId());

        startActivityForResult(inputActivityIntent, REQUEST_INPUT_ACTIVITY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==REQUEST_INPUT_ACTIVITY){
            //ignoring resultcode
            std=(Student)data.getSerializableExtra(STD_OBJ);
            updateUI();
        }
    }

    private void updateUI() {
        TextView txtName=findViewById(R.id.txtName);
        TextView txtReg=findViewById(R.id.txtReg);
        TextView txtCGPA=findViewById(R.id.txtCGPA);

        txtName.setText(std.name);
        txtReg.setText(std.reg.toString());
        txtCGPA.setText(std.cgpa.toString());
    }
}