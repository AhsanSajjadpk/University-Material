package com.example.test01;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class InputActivity extends AppCompatActivity {
    Student std;
    EditText edtData;
    Integer nID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        edtData=findViewById(R.id.edtData);
        Intent i=getIntent();

        std=(Student)i.getSerializableExtra(MainActivity.STD_OBJ);
        nID=i.getIntExtra(MainActivity.INPUT_FIELD, -1);

        if(nID==R.id.txtName){
            edtData.setHint("Enter name here");
        } else if(nID==R.id.txtReg){
            edtData.setHint("Enter registration here");
        }else if(nID==R.id.txtCGPA){
            edtData.setHint("Enter CGPA here");
        }
    }

    public void onBtnSave(View view) {
        String sData=edtData.getText().toString();

        if(nID==R.id.txtName){
            std.name=sData;
        } else if(nID==R.id.txtReg){
            std.reg=Integer.parseInt(sData);
        }else if(nID==R.id.txtCGPA){
            std.cgpa=Float.parseFloat(sData);
        }

        Intent intent=new Intent();
        intent.putExtra(MainActivity.STD_OBJ, std);
        setResult(0, intent);
        finish();
    }
}