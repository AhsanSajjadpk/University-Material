//Demonstrating textViewScrolling
package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtOutput;
    EditText edtText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtOutput=findViewById(R.id.txtOutput);
        edtText=findViewById(R.id.edtText);

        txtOutput.setMovementMethod(new ScrollingMovementMethod());

        String sLines="";
        for(int k=1;k<=100;k++)
            sLines+=k+"\n";
        txtOutput.setText(sLines);
    }

    public void onBtnSendClicked(View view) {
        txtOutput.setText( edtText.getText()+"\n"+txtOutput.getText() );

        edtText.setText("");
    }
}