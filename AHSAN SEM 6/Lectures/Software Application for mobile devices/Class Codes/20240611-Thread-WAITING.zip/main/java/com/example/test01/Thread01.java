package com.example.test01;

//wait() and notify can only be called within synchronized block

import android.util.Log;

public class Thread01 extends Thread {
    @Override
    public void run() {
        try {
            synchronized (this) {
                Log.d("abcd", "Waiting ...");
                wait();
                Log.d("abcd", "Done waiting ...");
            }
        } catch (Exception e) {
            Log.e("abcd", e.getMessage());
        }
    }
    public void stopWaiting() {
        synchronized (this) {
            notify();
        }
    }
}
