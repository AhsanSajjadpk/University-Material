package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onBtnStart(View view) {
        try {
            Thread01 th = new Thread01();
            th.start();
            Thread.sleep(500);
            Log.e("abcd", "State=" + th.getState());

            th.stopWaiting();//Indirect call to notify()
        } catch (Exception e) {
            Log.e("abcd", e.getMessage());
        }

    }
}