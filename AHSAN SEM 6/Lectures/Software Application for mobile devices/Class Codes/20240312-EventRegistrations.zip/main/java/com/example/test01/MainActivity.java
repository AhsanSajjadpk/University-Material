//Event registration
package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener {
    Button btnOK;
    Button btnOpen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOK=findViewById(R.id.btnOK);

        //By using listner interface
        btnOK.setOnClickListener(this);

        //By using anonymous inner class
        btnOpen=findViewById(R.id.btnOpen);
        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnOpen.setText("Close");
            }
        });
    }

    public void onBtnNextClicked(View view) {
        Button btn=(Button) view;
        btn.setText("Back");
    }

    @Override
    public void onClick(View v) {
        ((Button)v).setText("Cancel");
    }
}
