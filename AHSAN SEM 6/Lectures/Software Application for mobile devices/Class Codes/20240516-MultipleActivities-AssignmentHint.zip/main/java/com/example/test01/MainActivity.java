package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Intent intent;
    Intent intent2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intent=new Intent(getApplicationContext(), FullScreenActivity.class);
        intent2=new Intent(getApplicationContext(), DialogueActivity.class);
    }

    public void onBtn1Clicked(View view) {
        startActivity(intent);
    }

    public void onBtn2Clicked(View view) {
        startActivity(intent2);
    }
}